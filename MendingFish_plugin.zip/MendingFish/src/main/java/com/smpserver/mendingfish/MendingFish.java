package com.smpserver.mendingfish;

import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantInventory;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class MendingFish extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MendingFish aktif! Mending sadece balikciliktan gelir.");
    }

    // ✅ Balıkçılık - Mending gelirse duyuru yap, geçmesine izin ver
    @EventHandler(priority = EventPriority.MONITOR)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        if (event.isCancelled()) return;
        if (!(event.getCaught() instanceof Item)) return;

        Item caught = (Item) event.getCaught();
        ItemStack stack = caught.getItemStack();

        if (hasMending(stack)) {
            Player player = event.getPlayer();

            // Sunucu geneli duyuru
            String broadcast =
                "§6§l★ §e" + player.getName() + " §6az önce balık tutarak §b§lOnarım (Mending) §6kitabı buldu! §6§l★";
            Bukkit.broadcastMessage(broadcast);

            // Konsol logu
            getLogger().info("[MENDING] " + player.getName() + " Mending kitabi tuttu! "
                + "Konum: " + (int)player.getLocation().getX() + ", "
                + (int)player.getLocation().getY() + ", "
                + (int)player.getLocation().getZ());
        }
    }

    // ❌ Köylü ticaretinden Mending satın almayı engelle
    @EventHandler(priority = EventPriority.HIGH)
    public void onVillagerTrade(InventoryClickEvent event) {
        if (!(event.getInventory() instanceof MerchantInventory)) return;
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getRawSlot() != 2) return;

        MerchantInventory inv = (MerchantInventory) event.getInventory();
        MerchantRecipe recipe = inv.getSelectedRecipe();
        if (recipe == null) return;

        if (hasMending(recipe.getResult())) {
            event.setCancelled(true);
            event.getWhoClicked().sendMessage("§cKoylüler Onarim (Mending) satmaz. Onu kazanmak icin balik tut!");
        }
    }

    // ❌ Köylünün trade listesine Mending eklemesini engelle
    @EventHandler(priority = EventPriority.HIGH)
    public void onVillagerAcquireTrade(VillagerAcquireTradeEvent event) {
        if (hasMending(event.getRecipe().getResult())) {
            event.setCancelled(true);
        }
    }

    private boolean hasMending(ItemStack item) {
        if (item == null) return false;
        if (item.getItemMeta() instanceof EnchantmentStorageMeta) {
            return ((EnchantmentStorageMeta) item.getItemMeta()).hasStoredEnchant(Enchantment.MENDING);
        }
        return item.containsEnchantment(Enchantment.MENDING);
    }
}
